import React from 'react';

export default () => {
    return (
        <div className="loader">
            <span></span>
            <span></span>
            <span></span>
        </div>
    )
}